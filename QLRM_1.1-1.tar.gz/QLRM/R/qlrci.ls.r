qlr.ls <- function(formula, data, x.name=NULL, beta0=0){

	data <- data.frame(data)

	gm1 <- lm(formula, data=data, y=TRUE, x=TRUE)
	
	X <- gm1$x
	y <- gm1$y

	cn <- colnames(X)

	w0 <- which(cn==x.name)

	X1 <- X[,-c(1,w0)]
	x0 <- X[,w0]
	
	dt1 <- data.frame(y,X1)
	
	z1 <- beta0*x0
	
	gm2 <- glm(y ~ . , data=dt1, offset=z1, x=TRUE, y=TRUE)

	mu3 <- predict(gm2)
	
	mu3[mu3>1] <- 1
	mu3[mu3<0] <- 0
	
	LL1 <- logLik(gm1)
	LL0 <- logLik(gm2)
	
	T <- as.numeric(-2*(LL0 - LL1))			# 対数尤度比統計量

	R1 <- list(T=T,y=y,X=X,X1=X1,dt1=dt1,z1=z1,mu=mu3)

	return(R1)

}


bsqlr.ls <- function(formula, data, x.name=NULL, beta0=0, edfplot=TRUE, B=1000){

	data <- data.frame(data)
	
	n <- dim(data)[1]

	Q1 <- qlr.ls(formula, data, x.name=x.name, beta0)

	T <- Q1$T

	X1 <- Q1$X1
	X <- Q1$X[,-1]
	
	z1 <- Q1$z1

	Sr <- numeric(B)

	for(r in 1:B){
	
		yr <- rbinom(n, size=1, prob=Q1$mu)

		dat0 <- data.frame(yr,X1)
		dat1 <- data.frame(yr,X)

		lmr1 <- lm(yr ~ ., data=dat1, x=TRUE, y=TRUE)
		lmr0 <- lm(yr ~ ., data=dat0, offset=z1, x=TRUE, y=TRUE)

		LLr1 <- logLik(lmr1)
		LLr0 <- logLik(lmr0)

		Sr[r] <- as.numeric(-2*(LLr0 - LLr1))

	}
	
	Tc <- T/mean(Sr,na.rm=TRUE)

	P1 <- 1 - pchisq(Tc, df=1)
	
	ecdf1 <- ecdf(Sr)
	
	P2 <- 1 - ecdf1(T)
	
	if(edfplot==TRUE){
	
		plot(ecdf1,main="Bootstrap distribution of the QLR statistic",xlab="")
		abline(0.95, 0, lty=2, col="red")
		Q95 <- round(quantile(ecdf1,0.95),4)
		title(sub=paste0("95th percentile: ",Q95))
	
	}
	
	out <- list("QLR statistic"=T,"Mean calibrated QLR statistic"=Tc,"P-value for the mean calibrated QLR test"=P1,"P-value for the bootstrap QLR test"=P2)

	return(out)

}


qlrci.ls <- function(formula, data, x.name=NULL, B=200, cl=0.95, C0=10^-5, digits=4, seed=527916){

	set.seed(seed)

	a0 <- 1 - cl		# significant level

	qm1 <- rqlm(formula, data=data, family=gaussian, eform=FALSE, cl=cl, digits=digits)
	qm2 <- rqlm(formula, data=data, family=gaussian, eform=FALSE, cl=cl, digits=999999)

	wx <- which(rownames(qm2)==x.name)

	e1 <- qm2[wx,1]
	se1 <- qm2[wx,2]
	cl1 <- qm2[wx,3]
	cu1 <- qm2[wx,4]

	# Exploring lower limits
	
	P0 <- bsqlr.ls(formula, data=data, x.name, beta0=e1, edfplot=FALSE, B=B)[[3]]
	P1 <- bsqlr.ls(formula, data=data, x.name, beta0=cl1, edfplot=FALSE, B=B)[[3]]

	U1	<-	e1		# 上限の初期値

	if(P1 < a0)	L1 <- cl1		# 下限の初期値

	if(P1 >= a0){
	
		a1 <- 1
	
		while(P1 >= a0){
		
			a2 <- cl1 - a1*se1
			
			P1 <- bsqlr.ls(formula, data=data, x.name, beta0=a2, edfplot=FALSE, B=B)[[3]]

			a1 <- a1 + 1
			
			if(a1 >= 20) return("Error: Singular problems occur, please contact the authors.")
			
		}
		
		L1 <- a2

	}
	
	message("The computationl process 1/4 was completed.")

	D1 <- U1 - L1

	while(D1 > C0){

		M1 <- (L1 + U1)/2

		P2 <- bsqlr.ls(formula, data=data, x.name, beta0=M1, edfplot=FALSE, B=B)[[3]]
		
		if(P2 >= a0) U1 <- M1
		if(P2 < a0) L1 <- M1
		
		D1 <- U1 - L1

	}
	
	CL <- M1		# 下側の信頼限界を確定

	message("The computationl process 2/4 was completed.")

	# Exploring upper limits
	
	P0 <- bsqlr.ls(formula, data=data, x.name, beta0=e1, edfplot=FALSE, B=B)[[3]]
	P1 <- bsqlr.ls(formula, data=data, x.name, beta0=cu1, edfplot=FALSE, B=B)[[3]]

	L1	<-	e1		# 下限の初期値

	if(P1 < a0)	U1 <- cu1		# 上限の初期値

	if(P1 >= a0){
	
		a1 <- 1
	
		while(P1 >= a0){
		
			a2 <- cu1 + a1*se1
			
			P1 <- bsqlr.ls(formula, data=data, x.name, beta0=a2, edfplot=FALSE, B=B)[[3]]

			a1 <- a1 + 1

			if(a1 >= 20) return("Error: Singular problems occur, please contact the authors.")
			
		}
		
		U1 <- a2

	}

	message("The computationl process 3/4 was completed.")

	D1 <- U1 - L1

	while(D1 > C0){

		M1 <- (L1 + U1)/2

		P2 <- bsqlr.ls(formula, data=data, x.name, beta0=M1, edfplot=FALSE, B=B)[[3]]
		
		if(P2 >= a0) L1 <- M1
		if(P2 < a0) U1 <- M1
		
		D1 <- U1 - L1
		
	}
	
	CU <- M1		# 上側の信頼限界を確定

	message("The computationl process 4/4 was completed.")
	message(" ")

	out2 <- round(c(CL,CU),digits)

	P2 <- round(bsqlr.ls(formula, data=data, x.name, beta0=0, edfplot=FALSE, B=B)[[3]],digits)

	R1 <- list("Modified least-squares regression with the Wald-type approximation"=qm1, "QLR confidence interval for the corresponding covariate"=out2,
			"P-value"=P2)
			
	return(R1)

}

