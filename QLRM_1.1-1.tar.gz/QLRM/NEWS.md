# QLRM 1.1-1 (2024-01-17)

- first version released on GitHub
